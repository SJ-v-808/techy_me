                              |Forensic tool manuals|

*  $install_pakg: used for installing required packages   *
*  $use_tools   : used for using forensic tools           *
		> $show_exif     | display exif data    |
		> $show_f_in_f   | search hidden files  |
		> $show_hex	 | show hex of files    |
		> $show_s	 | show strings of files|
		> $extract_f_in_f| extract hidden files |
		> $man           | show manuals         |
		> $back	         | go back to main menu |
		> $c             | clear screen         |
*  $c           : used for clearing screen                *
*  $q           : used to exit the programm               *
*  $man         : show manuals                            *

